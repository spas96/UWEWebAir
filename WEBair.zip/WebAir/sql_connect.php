<?php
mysql_connect("localhost", "root", "") or die("mysql connection is failure.");
mysql_select_db("webair") or die("Database does not exists.");
?>