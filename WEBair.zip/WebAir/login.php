<?php
require ('sql_connect.php');
require ('resultstest.html');
if (isset($_POST['submit'])){
#setting variables for username and password on the form
$username=mysql_real_escape_string($_POST['useremail']);
$password=mysql_real_escape_string($_POST['pw']);

/*
$page_login = "";
*/
//setcookie($page_login, $username, time() + (86400 * 30), "/"); // 86400 = 1 day

if (!$_POST['useremail'] | !$_POST['pw'])
{
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('You did not complete all of the required fields')
        window.location.href='resultstest.html'
        </SCRIPT>");
exit();	
}
	 
$sql= mysql_query("SELECT * FROM `login` WHERE `lg_email` = '$username' AND `lg_password` = '$password' AND `lg_usertype` = 'admin'");
if(mysql_num_rows($sql) > 0)
{
		/*session_name('login_admin');
		session_start();
		$_SESSION['login_admin'] = $username;*/
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Admin Login Succesful!')
        window.location.href='adminpage.html'
        </SCRIPT>");
		exit();
exit();
}

$sql= mysql_query("SELECT * FROM `login` WHERE `lg_email` = '$username' AND `lg_password` = '$password' AND `lg_usertype` = 'customer'");
if(mysql_num_rows($sql) > 0)
{
		$_SESSION['login_customer'] = $username;
echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Customer Login Succesful!')
        window.location.href='userpage.html'
        </SCRIPT>");
exit();
}

else
{
}
}
else{
}

?>