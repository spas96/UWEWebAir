#! /Python34/python
import cgi, cgitb, sys, mysql.connector
print("Content-type: text/html \n")

cgitb.enable()

form = cgi.FieldStorage()

conn = mysql.connector.connect(host='localhost',
								database='webair',
								user='root',
								password='')
		

print("""

<head>
<meta charset="utf-8">
<link rel="StyleSheet" href="try.css" type="text/css" media="screen">
<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>

<script>
$(document).ready(function () {
	"use strict"
	
	$("html,body").animate({scrollTop: 0}, 500);

})
window.addEventListener("load", function(){
	var load_screen = document.getElementById("load_screen");
	$("#load_screen").animate({ opacity: '0'}, 3000, function(){
	document.body.removeChild(load_screen);
	});
	});
	
	function slider() {
		var obj = document.getElementById('slide'); 
		obj.style.visibility = (obj.style.visibility == 'visible') ? 'hidden' : 'visible';
		obj.style.height = (obj.style.height == '0px' || obj.style.height == '') ? '150px' : '0px';
	}

</script>
<script>
jQuery(function($){ //on document.ready
Object.defineProperty(Array.prototype, "remove", {
    enumerable: false,
    value: function (itemToRemove) {
        var removeCounter = 0;

        for (var index = 0; index < this.length; index++) {
            if (this[index] == itemToRemove) {
                this.splice(index, 1);
                removeCounter++;
                index--;
            }
        }
        return removeCounter;
    }
});

})

</script>
</head>


<body>
<div class="mpc_preloader" id="load_screen">
	<div class="mpc_preloader18"></div>
	<span class="mpc_preloader18_label">Loading...</span>
</div>

	<div id="wrapper">
		<div id="header">

		<div id="main1-left-clamp-results">
		
			<div id="clamp-gradient">
			</div>
		
		</div>
		
		<div id="main1-right-clamp-results">
		
			<div id="clamp-gradient">
			</div>
		
		</div>
			<div id="box-shadow"></div>
			<div id="header-gradient">
			
				<div id="header-position">
					
					<form>
						<a href="/webprog/WebAir/" id="home" style="border-bottom: 1px solid #e02e36;" class="button-top">Home</a>
						<a href="/webprog/WebAir/flightsinfo.py" id="info" class="button-top">Flights Info</a>
						<a href="/webprog/WebAir/manage_ticket.py" id="manage" class="button-top">Manage Ticket</a>
						<a href="/webprog/WebAir/aboutus.html" id="about" class="button-top">About Us</a>
					</form>
					
				</div>
				<p class="account" onclick="slider();">Account</p>
			</div>
		<div id="logo-box">
			<img src="http://i67.tinypic.com/f6w5i.png" style="width:100%;height:100%;">
		</div>
		</div>

			<div id="results-page" style="margin-top:62px;">
			<!-- Start -->
		<form id="myForm" style="padding-left: 10px;padding-right: 10px;padding-bottom: 10px;">
			<center><H1	style="padding-top: 10px;">Flights Information!</H1></center>
			<p>Welcome to WebAir! Here we pride ourselves on affordable and consistent journeys all across the UK from as North as Glasgow all the way down to Southampton.</p>
			<H2>Child Discounts!</H2>
				<p>Here at WebAir we like to offer the customer the most we should give back to the customer.</p>
				<ul>
					<li>All children (passengers under 10 years old) receive a 20% discount if accompanied by an adult.</li>
					<li>However, children travelling alone attract the full adult fare.</li>
				</ul>
			<!--Grab from database-->
			<H2>Flights Routes</H2>
			<center>
				<style>	table, th, td {border: 1px solid black; border-collapse: collapse; font-size: 9;}th, td {padding: 10px;}</style>
				<table cellspacing="1" cellpadding="2" border="1">
					<tr>
						<td align="left"><b>Leave Destination</b></td>
						<td align="left"><b>Leave Time</b></td>
						<td align="left"><b>Arrive Destination</b></td>
						<td align="left"><b>Arrive Time</b></td>
						<td align="left"><b>Journey Fare(&pound;)</b></td>
					</tr>
					""")
					
########################################################################################################################

print("""
<tr>
	<td align="left">
""")						
#1st row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '1'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '1'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '1'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '1'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '1'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#2nd row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '2'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '2'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '2'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '2'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '2'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
			
########################################################################################################################

print("""
<tr>
	<td align="left">
""")						
#3rd row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '3'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '3'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '3'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '3'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '3'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()

########################################################################################################################

print("""
<tr>
	<td align="left">
""")						
#4th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '4'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '4'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '4'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '4'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '4'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#5th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '5'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '5'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '5'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '5'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '5'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#6th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '6'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '1'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '6'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '6'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '6'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#7th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '7'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '7'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '7'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '7'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '7'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#8th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '8'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '8'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '8'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '8'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '8'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#9th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '9'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '9'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '9'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '9'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '9'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#10th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '10'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '10'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '10'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '10'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '10'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#11th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '11'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '11'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '11'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '11'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '11'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#12th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '12'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '12'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '12'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '12'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '12'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#13th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '13'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '13'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '13'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '13'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '13'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#14th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '14'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '14'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '14'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '14'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '14'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#15th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '15'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '15'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '15'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '15'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '15'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#16th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '16'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '16'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '16'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '16'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '16'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#17th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '17'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '17'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '17'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '17'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '17'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""
<tr>
	<td align="left">
""")
#18th row
#1 leave dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_leave_destination` FROM `journey_times` WHERE `jt_route_number` = '18'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")

#2 leave time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '18'")
        row = cursor.fetchone()
        print(row[2])
        cursor.close()
print("""</td>
<td align="left">""")
#3 arrive dest
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_arrive_destination` FROM `journey_times` WHERE `jt_route_number` = '18'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""</td>
<td align="left">""")
#4 arrive time
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM `journey_times` WHERE `jt_route_number` = '18'")
        row = cursor.fetchone()
        print(row[4])
        cursor.close()
print("""</td>
<td align="left">""")
#5 fare
if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("SELECT `jt_journey_fare` FROM `journey_times` WHERE `jt_route_number` = '18'")
        row = cursor.fetchone()
        row = str(row)
        row = row.replace("(", "")
        row = row.replace(")", "")
        row = row.replace(",", "")
        row = row.replace("'", "")
        print(row)
        cursor.close()
print("""
</td>
	</tr>
""")

########################################################################################################################

print("""</td>
</tr>
				</table>
			</center>
			<p>Any future routes and all current routes will always be stored in ths table.</p>
			<H2>WebAir Ticket cancel policy</H2>
				<p>We understand that sometimes you may decide that you don't to go on the journey you intended on, and may want to cancel the ticket. We allow ticket cancellation at any point during the booking process and after you've received your ticket. </p>
				<p>Below is the cancellation policy of WebAir:</p>
				<ul>
					<li>Cancellations can be made at least 72 hours in advance to a journey.</li>
					<li>Any cancellation 72 hours before the departure time will refund 50% of the ticket price.</li>
					<li>Any cancellation after the 72 hour window will not refund anything.</li>
					<li>Any ticket cancellations will notify the customer before/after the cancellation event.</li>
				</ul>""")
print("""
<p>
      <span class="nowrap">For cancellation specific to your ticket <a href= "/webprog/WebAir/manage_ticket.py">click here</a></span>
      <span class="nowrap">to visit the manage ticket page.</span>
</p>
""")
print("""
		</form>
		<!-- end -->
		
		
		
		</div>
		<div id="footer">
		<div id="box-shadow"></div>
			<div id="header-gradient">
				<div id="footer-position">
					&#174 2016 UWE WebAir. All rights reserved. 
				</div>
			</div>

		</div>
		<div id="slide" class="slide">
	  		<div id="logo-box">
				<form>
					<p style="font-size:13px;">Sign in to see exclusive Member Pricing</p>
					<form action="resultstest.html">
						<a href = "resultstest.html" class="button1">Sign in </a>
					<p>New? <a href="/webprog/WebAir/Sign_Up.html" style="color:red;">Create an Account</a></p>
				</form>
			</div>
		</div>
    </div>
</body>
</html>
""")
conn.close()
