function validateAlpha(){
    var textInput = document.getElementById("start_dest").value;
    textInput = textInput.replace(/[^A-Za-z]/g, "");
    document.getElementById("start_dest").value = textInput;
}
function validateAlpha2(){
    var textInput = document.getElementById("end_dest").value;
    textInput = textInput.replace(/[^A-Za-z]/g, "");
    document.getElementById("end_dest").value = textInput;
}
function validateAlpha3(){
    var textInput = document.getElementById("user_title").value;
    textInput = textInput.replace(/[^A-Za-z]/g, "");
    document.getElementById("user_title").value = textInput;
}
function validateAlpha4(){
    var textInput = document.getElementById("user_lname").value;
    textInput = textInput.replace(/[^A-Za-z]/g, "");
    document.getElementById("user_lname").value = textInput;
}
function validateAlpha5(){
    var textInput = document.getElementById("user_fname").value;
    textInput = textInput.replace(/[^A-Za-z]/g, "");
    document.getElementById("user_fname").value = textInput;
}
function changetxt(){
    var elem = document.getElementById("amenduserbtn1");
    if (elem.value=="Change Details") elem.value = "Save Changes";
    else elem.value = "Change Details";
}