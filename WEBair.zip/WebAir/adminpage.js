function validateAlpha(){
    var textInput = document.getElementById("start_dest").value;
    textInput = textInput.replace(/[^A-Za-z]/g, "");
    document.getElementById("start_dest").value = textInput;
}
function validateAlpha2(){
    var textInput = document.getElementById("end_dest").value;
    textInput = textInput.replace(/[^A-Za-z]/g, "");
    document.getElementById("end_dest").value = textInput;
}
function validateAlpha3(){
    var textInput = document.getElementById("user_title").value;
    textInput = textInput.replace(/[^A-Za-z]/g, "");
    document.getElementById("user_title").value = textInput;
}
function validateAlpha4(){
    var textInput = document.getElementById("user_lname").value;
    textInput = textInput.replace(/[^A-Za-z]/g, "");
    document.getElementById("user_lname").value = textInput;
}
function validateAlpha5(){
    var textInput = document.getElementById("user_fname").value;
    textInput = textInput.replace(/[^A-Za-z]/g, "");
    document.getElementById("user_fname").value = textInput;
}
function validateNum(){
    var textInput = document.getElementById("flight_id").value;
    textInput = textInput.replace(/[^0-9]/g, "");
    document.getElementById("flight_id").value = textInput;
}
function validateNum2(){
    var textInput = document.getElementById("user_id").value;
    textInput = textInput.replace(/[^0-9]/g, "");
    document.getElementById("user_id").value = textInput;
}
function validateNumType(){
    var textInput = document.getElementById("user_type").value;
    textInput = textInput.replace(/[^1-3]/g, "");
    document.getElementById("user_type").value = textInput;
}
function validateNum3(){
    var textInput = document.getElementById("max_seats").value;
    textInput = textInput.replace(/[^0-9]/g, "");
    document.getElementById("max_seats").value = textInput;
}